<?php 
 
class Jqview{ 
	public static $debug=true;
	public static function view($htmlfile,$opt=array()){    
		$file = __DIR__.'/temp/'.md5($htmlfile).'.x';  
		if( !self::$debug and @filemtime($htmlfile) < @filemtime($file) ); else{   
			$doc = phpQuery::newDocumentFileHTML($htmlfile); 
			self::_extend($doc,$htmlfile);
			self::_phps($doc);  
			self::_each($doc);  
			self::_text($doc);   
			$od = dirname($file) ;
			if( !is_dir($od) )mkdir($od);
			file_put_contents($file,$doc); 
		} 
		extract($opt);
		include $file;
	} 
	static function _each($doc){
		$doc['[_each]']->each(function($me){
			$self = pq($me); 
			$self->before("<?php foreach(".$self->attr('_each')."){ ?>");
			$self->after("<?php } ?>"); 
			$self->removeAttr('_each');
		}); 
	}
	static function _text($doc){ 
		$doc['[_text]']->each(function($me){
			$self = pq($me);
			$self->html('<?php if($_='.$self->attr('_text').'){echo $_;}else{?>'.$self->html().'<?php } ?>');
			$self->removeAttr('_text'); 
		}); 
	}
	static function _phps($doc){ 
		$doc['[_php]']->each(function($me){
			$self = pq($me);
			$self->append("<?php".$self->attr('_php')." ?>");
			$self->removeAttr('_php');  
		});   
	}
	static function _extend(&$doc,$htmlfile ){    
		$block = $doc['[_block]'];
		do{ 
			$dom = $doc['[_extend]'] ; 
			$htmlfile =  dirname($htmlfile).'/'.$dom->attr('_extend');
			if( !$dom->length || !file_exists($htmlfile) )break;
			$doc = phpQuery::newDocumentFileHTML($htmlfile); 
			$block = $doc['[_block]']->add($block); 
		}while(true); 
		$block->each(function($t) use( $doc ){  
			$tx = "[_block=".pq($t)->attr('_block')."]";   
			$doc[$tx]->html(  pq($t)->html() );   
		}); 
		$doc['[_block]']->each(function($me){ 
			$self = pq($me);
			$self->removeAttr('_block');  
		});
		$doc['[_extend]']->each(function($me){ 
			$self = pq($me);
			$self->removeAttr('_extend');  
		}); 
	} 
	static function _include($doc){
		$doc['_include']->each(function($me){
			$self = pq($me);
			$self->html("<?php include '".$self->attr('_include')."' ?>");
			$self->removeAttr('_include');  
		});   
	}
}